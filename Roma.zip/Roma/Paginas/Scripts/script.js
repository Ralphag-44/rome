function p_no(){
    num_p = document.getElementById("num_p").value 
    if (num_p > 20 || num_p < 2){
        alert("Valor Inválido, o número de Jogadores deverá ser de no mínimo 2, e no máximo 20")

    }
    else {
    document.getElementById("glad_n").innerHTML = ''
    for (i = num_p; i > 0; i--){
        document.getElementById("glad_n").innerHTML += '<tr><td><input type="text"></td></tr>'
    }
}
}
function auto_no(){
    defl_names = ['Spartacus', 'Comôdo', 'Flamma', 'Carpoporus', 'Secutor', 'Retiarius', 'Priscus', 'Verus', 'Tetraites', 'Prudentius', 'Hermes', 'Bato', 'Crixus', 'Comodianos', 'Artemidorus', 'Asteropaeus', 'Rutuba', 'Diodorus', 'Achillia', 'Aenomao']
    window.cont = document.getElementById("glad_n").rows.length
    document.getElementById("glad_n").innerHTML = ''
    for (i = 0; i < window.cont; i++){
        document.getElementById("glad_n").innerHTML += '<tr><td><input type="text" value='+ defl_names[i] +'></td></tr>'
    }

}

function mashup(){
play_list = []
rep = []
for (i = 0; i < window.cont; i++){
    pos = parseInt(Math.random()*window.cont)
    if (rep.indexOf(pos) < 0){
    play_list[pos] = (document.getElementById("glad_n").rows[i].cells[0].firstChild.value)
    rep.push(pos)
    }
    else {
     i--
    }
}    
alert(play_list)

}